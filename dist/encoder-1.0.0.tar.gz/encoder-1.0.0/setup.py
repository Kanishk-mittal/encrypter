from setuptools import setup
setup(name="encoder",
version="1.0.0",
description="This is an encoder package",
long_description="This is python package helps us encode a given text using some basic encryption algorithms",
author="Kanishk",
packages=["encoder"],
install_requires=["nltk"]
)